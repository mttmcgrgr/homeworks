class DeleteUserIdColumn < ActiveRecord::Migration
  def change
    change_column_null :cats, :user_id, true 
  end
end
