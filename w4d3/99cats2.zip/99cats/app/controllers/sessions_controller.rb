class SessionsController < ApplicationController

  before_action :cats_url

  def create
    user = User.find_by_credentials(session_params[:user_name], session_params[:password])
    if user
      user.reset_session_token!
      log_in(user)
      flash[:messages] = ["Welcome back!"]
      redirect_to user_url(user)
    else
      flash.now[:messages] = ["Invalid credentials. Cannot log in."]
      render :new
    end
  end

  def new
    if current_user
      flash[:messages] = ["You are already logged in!"]
      redirect_to user_url(current_user)
    else
      render :new
    end
  end

  def destroy
    current_user.reset_session_token! if current_user
    session[:session_token] = nil
    log_out
    redirect_to new_session_url
  end

  private

  def session_params
    params.require(:session).permit(:user_name, :password)
  end
end
