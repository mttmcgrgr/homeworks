class UsersController < ApplicationController

  before_action :cats_url

  def show
    @user = User.find_by(id: params[:id])

    if @user
      render :show
    else
      flash[:messages] = ["User does not exist!"]
      redirect_to cats_url
    end
  end

  def new
    if current_user
      flash[:messages] = ["You are already logged in."]
      redirect_to user_url(current_user)
    else
      render :new
    end
  end

  def create

    @user = User.new(user_params)
    if @user.save
      log_in(@user)
      redirect_to user_url(@user)
    else
      flash.now[:messages] = ["User credentials invalid"]
      render :new
    end
  end


  private

  def user_params
    params.require(:user).permit(:user_name, :password)
  end
end
